import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

import java.util.Comparator;

public class Solver {
    private Stack<Board> solvedBoards;
    private int moves;
    private boolean solvable;

    public Solver(Board initial) {
        SearchNode board = new SearchNode(initial, 0, null), twin = new SearchNode(initial.twin(), 0, null),
            prev = null, tprev = null;

        moves = 1;
        solvable = false;

        // Priority queues for twin board and initial board
        MinPQ<SearchNode> q = new MinPQ<>(new SearchNodeComparator());
        MinPQ<SearchNode>  tq = new MinPQ<>(new SearchNodeComparator());

        // Add the initial board to the priority queues
        q.insert(board);
        tq.insert(twin);
        while (!board.board().isGoal() && !twin.board().isGoal()) {
            // Insert original board neighbors
            for (Board b : board.board().neighbors())
                if (!b.equals(prev == null ? null : prev.board()))
                    q.insert(new SearchNode(b, moves, board));

            // Insert twin board neighbors
            for (Board b : twin.board().neighbors())
                if (!b.equals(tprev == null ? null : tprev.board()))
                    tq.insert(new SearchNode(b, moves, twin));

            // Set the previous nodes
            prev = board;
            tprev = twin;

            // Find the minimum elements for twin and board
            board = q.delMin();
            twin = tq.delMin();

            // Increment moves
            moves++;
        }

        // Delete queues
        q = null;
        tq = null;

        if (board.board().isGoal()) {
            // Set solvable to true
            solvable = true;

            // Copy the solution by working backword along the pointers starting with the goal board
            solvedBoards = new Stack<>();
            solvedBoards.push(board.board());
            while ((board = board.previous()) != null)
                solvedBoards.push(board.board());
        }
    }

    public boolean isSolvable() {
        return solvable;
    }

    public int moves() {
        return isSolvable() ? solvedBoards.size() - 1 : -1;
    }

    public Iterable<Board> solution() {
        return solvedBoards;
    }

    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }

    private static class SearchNode {
        private final Board board;
        private final SearchNode previous;
        private final int moves;

        public SearchNode(Board board, int moves, SearchNode previous) {
            this.board = board;
            this.moves = moves;
            this.previous = previous;
        }

        public Board board() {
            return board;
        }

        public SearchNode previous() {
            return previous;
        }

        public int moves() {
            return moves;
        }
    }

    private static class SearchNodeComparator implements Comparator<SearchNode> {

        @Override
        public int compare(SearchNode o1, SearchNode o2) {
            int m1 = o1.board().manhattan() + o1.moves();
            int m2 = o2.board().manhattan() + o2.moves();
            if (m1 == m2)
                return Integer.compare(o1.board().hamming() + o1.moves(), o2.board().hamming() + o2.moves());
            return Integer.compare(m1, m2);
        }
    }
}
